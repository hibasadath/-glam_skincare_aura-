
import React from 'react';
export default function CameraScanner() {
  return <div className="p-6 text-center text-slate-400">Scanner has been removed. Please use manual selection.</div>;
}
