
// This file is intentionally left mostly empty or can be removed.
// The app now uses manual skin type selection.
export const analyzeSkinImage = async () => {
  throw new Error("AI Analysis is disabled in this version.");
};
